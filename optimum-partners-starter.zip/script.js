// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Lead form handler (progressive enhancement)
const form = document.getElementById('lead-form');
const status = document.getElementById('form-status');

if (form) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    status.textContent = 'Sending…';
    const data = new FormData(form);

    // Save to localStorage as a backup (mobile-friendly)
    try { localStorage.setItem('optimum_last_lead', JSON.stringify(Object.fromEntries(data))); } catch {}

    // If you set up Formspree, replace 'your_form_id' in index.html action
    try {
      const res = await fetch(form.action, { method: 'POST', body: data, headers: { 'Accept': 'application/json' } });
      if (res.ok) {
        status.textContent = 'Thanks! We will reach out shortly.';
        form.reset();
      } else {
        status.textContent = 'There was a problem sending your request. Please call (305) 890‑3456.';
      }
    } catch (err) {
      status.textContent = 'Network issue. You can also call (305) 890‑3456.';
    }
  });
}

// Simple client-side bot placeholder (captures a lead even without a backend)
const toggle = document.getElementById('chat-toggle');
const widget = document.getElementById('chat-widget');
const closeBtn = document.getElementById('chat-close');
const chatBody = document.getElementById('chat-body');
const chatForm = document.getElementById('chat-form');
const chatText = document.getElementById('chat-text');

function openChat() {
  widget.style.display = 'block';
  widget.setAttribute('aria-hidden', 'false');
  chatText.focus();
}
function closeChat() {
  widget.style.display = 'none';
  widget.setAttribute('aria-hidden', 'true');
}
toggle?.addEventListener('click', openChat);
closeBtn?.addEventListener('click', closeChat);

// Minimal rule-based flow to collect name + phone + service
let convo = { step: 0, payload: {} };

chatForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = chatText.value.trim();
  if (!text) return;
  addMsg('user', text);
  chatText.value = '';

  setTimeout(() => {
    if (convo.step === 0) {
      convo.payload.name = text;
      addMsg('bot', 'Nice to meet you, ' + text + '! What service do you need? (roof replacement, repair, interior)');
      convo.step = 1;
    } else if (convo.step === 1) {
      convo.payload.service = text;
      addMsg('bot', 'Got it. What’s the best phone number to reach you?');
      convo.step = 2;
    } else if (convo.step === 2) {
      convo.payload.phone = text;
      addMsg('bot', 'Thanks! One moment while I log your request…');
      // Try sending to the same Formspree endpoint as the main form (if configured)
      const payload = new FormData();
      payload.append('name', convo.payload.name || '');
      payload.append('service', convo.payload.service || '');
      payload.append('phone', convo.payload.phone || '');
      payload.append('source', 'Chat Widget');
      fetch(document.getElementById('lead-form')?.action || '#', {
        method: 'POST',
        body: payload,
        headers: { 'Accept': 'application/json' }
      }).then(() => {
        addMsg('bot', 'All set ✅ A team member will text or call you shortly. You can also tap “Get a Free Quote” to send details.');
      }).catch(() => {
        addMsg('bot', 'Saved locally. If sending fails, please call (305) 890‑3456.');
      });
      try { localStorage.setItem('optimum_last_bot_lead', JSON.stringify(convo.payload)); } catch {}
      convo.step = 3;
    } else {
      addMsg('bot', 'A specialist will follow up soon. Anything else I can add?');
    }
  }, 300);
});

function addMsg(role, text) {
  const div = document.createElement('div');
  div.className = role === 'bot' ? 'bot' : 'user';
  div.textContent = text;
  chatBody.appendChild(div);
  chatBody.scrollTop = chatBody.scrollHeight;
}

// If you later add a real bot/service (Crisp, Tidio, Intercom, custom API):
// 1) Remove this placeholder widget
// 2) Paste their script tag here, or wire chatForm submit to your API
